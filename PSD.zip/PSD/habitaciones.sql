insert into habitacion (nombre, imagen, precio, tipo_id) values ('Habitación primera', 'h_primera.jpg', 100, 1);
insert into habitacion (nombre, imagen, precio, tipo_id) values ('Habitación segunda', 'h_segunda.jpg', 110, 1);
insert into habitacion (nombre, imagen, precio, tipo_id) values ('Habitación tercera', 'h_tercera.jpg', 120, 1);

insert into habitacion (nombre, imagen, precio, tipo_id) values ('Habitación doble primera', 'h_d_primera.jpg', 150, 2);
insert into habitacion (nombre, imagen, precio, tipo_id) values ('Habitación doble segunda', 'h_d_segunda.jpg', 155, 2);
insert into habitacion (nombre, imagen, precio, tipo_id) values ('Habitación doble tercera', 'h_d_tercera.jpg', 160, 2);
insert into habitacion (nombre, imagen, precio, tipo_id) values ('Habitación doble cuarta', 'h_d_cuarta.jpg', 165, 2);
insert into habitacion (nombre, imagen, precio, tipo_id) values ('Habitación doble quinta', 'h_d_quinta.jpg', 170, 2);

insert into habitacion (nombre, imagen, precio, tipo_id) values ('Habitación suite junior', 'suite_junior.jpg', 250, 3);
insert into habitacion (nombre, imagen, precio, tipo_id) values ('Habitación suite nupcial', 'suite_nupcial.jpg', 300, 3);