<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
		<link rel="stylesheet" href="./css/reset.css" />
		<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="./css/estilos.css" />
	</head>
	<body>
		<div id="menu">
			<div id="menuContent">
				<div id="logotipo"><h1>Symfony II Hotel</h1></div>
				<div id="opciones">
					<ul>
						<li>Hotel</li>
						<li>Habitaciones & Suites</li>
						<li>Reservas</li>
						<li>Actividades</li>
						<li>Contacto</li>
					</ul>
				</div>
				<div id="idiomas"><select name="idioma"><option>ES</option><option>EN</option></select></div>
				<div class="clear"></div>
			</div>
		</div>
		<div id="fondo">
		</div>
		<div id="main">
			<div id="cabecera">
			<div id="slogans">
				<div id="c_s_1">
					<div id="s_1">Es más que un hotel, es lo que tú necesitas</div>
					<div id="bg_s_1"> </div>
				</div>
				<br/>
				<div id="c_s_2">
					<div id="s_2">Increíble lugar por descubrir</div>
					<div id="bg_s_2"> </div>
				</div>
			</div>
			</div>
			<div id="reserva">
				<div id="info">
					<h3>Reserva tu habitación online</h3>
					<p>Lorem ispum solor sid ahmed loresin vane.</p>
				</div>
				<div id="formReserva">
					<form method="POST" action="">
						<div>
							<span>Tipo de habitación:</span><br/>
							<select name="habitacion"><option>Habitación individual</option><option>Habitación doble</option><option>Habitación suite</option></select>
						</div>
						
						<div>
							<span>Fecha de entrada:</span><br/>
							<input type="text" name="fechaEntrada" />
						</div>
						
						<div>
							<span>Fecha de salida:</span><br/>
							<input type="text" name="fechaSalida" />
						</div>
						
						<div>
							<span>Adultos:</span><br/>
							<select name="adultos"><option>1</option><option>2</option></select>
						</div>
						
						<div>
							<span>Niños:</span><br/>
							<select name="ninios"><option>0</option><option>1</option><option>2</option></select>
						</div>
						
						<div>
							<span> </span><br/>
							<input type="submit" value="Reservar" />
						</div>
					</form>
				</div>
			</div>
			<div id="informacion">
				<ul>
					<li>
						<img src="./imgs/1.jpg" />
						<h4>Habitación individual <span>110 €</span></h4>
						<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
					</li>
					<li>
						<img src="./imgs/2.jpg" />
						<h4>Habitación doble <span>180 €</span></h4>
						<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
					</li>
					<li>
						<img src="./imgs/3.jpg" />
						<h4>Habitación suite <span>210 €</span></h4>
						<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
					</li>
				</ul>
			</div>
		</div>
		<div id="pie">
			<div id="pieContent">
				<div>&#169; 2014 Symfony II Hotel.</div>
				<div id="social"><img src="./imgs/social.png" /></div>
				<div>
					<ul>
						<li>Contacto</li>
						<li>Reservas</li>
						<li>Habitaciones & Suites</li>
						<li>Hotel</li>
					</ul>
				</div>
			</div>
		</div>
		
		<script src="./js/jquery-1.11.0.min.js"></script>
		<script>
			$(window).load(function(){
				$(window).scroll(function () {
					if ($(this).scrollTop() > 325) {
						$('#reserva').css({"position": "fixed", "width": "980px", "top": "100px"});
						$('#cabecera').css("margin-bottom", "145px");
					} else {
						$('#reserva').css({"position": "relative", "width": "100%", "top": ""});
						$('#cabecera').css("margin-bottom", "0px");
					}
				});
			});
		</script>
	</body>
</html>